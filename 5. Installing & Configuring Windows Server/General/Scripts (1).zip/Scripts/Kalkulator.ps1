﻿# Ask the user for two numbers
$number1 = Read-Host "Enter the first number"
$number2 = Read-Host "Enter the second number"

# Convert input to integer
$number1 = [int]$number1
$number2 = [int]$number2

do {
    # Display options to the user
    Write-Host "Choose an operation:"
    Write-Host "1: Addition"
    Write-Host "2: Subtraction"
    Write-Host "3: Multiplication"
    Write-Host "4: Division"
    Write-Host "5: Exit"
    $choice = Read-Host "Enter your choice (1-5)"
    
    switch ($choice) {
        '1' {
            $result = $number1 + $number2
            Write-Host "Result of Addition: $result"
        }
        '2' {
            $result = $number1 - $number2
            Write-Host "Result of Subtraction: $result"
        }
        '3' {
            $result = $number1 * $number2
            Write-Host "Result of Multiplication: $result"
        }
        '4' {
            if ($number2 -eq 0) {
                Write-Host "Cannot divide by zero."
            } else {
                $result = $number1 / $number2
                Write-Host "Result of Division: $result"
            }
        }
        '5' {
            Write-Host "Exiting..."
            break
        }
        default {
            Write-Host "Invalid choice, please select a valid option."
        }
    }
} while ($choice -ne '5')
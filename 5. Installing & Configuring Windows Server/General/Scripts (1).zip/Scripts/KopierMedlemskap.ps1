﻿Import-Module ActiveDirectory
$users = Get-AdUser -Filter * -SearchBase "Forskning=OU, Brukere og grupper=OU, Mosvik=OU, GeekGulp=OU, geekgulp=DC, NO=DC"
$sourceuser = Get-ADUser -Identity peptun -Properties MemberOf
$SourceGroups = $sourceuser.MemberOf



Foreach($group in $SourceGroups) {
    $thisgroup = $group.split(",")[0].split("=")[1]
    Add-ADGroupMember -identity $thisgroup -members $users
}

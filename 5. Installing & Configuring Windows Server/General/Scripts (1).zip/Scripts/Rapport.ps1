﻿
# Define the username and
$username = Read-Host "Hvilken bruker vil du ha repport på?"
$domain = Read-Host

# Path to save the RSoP report
$date = (Get-Date).ToString("yyyy-MM-dd-ss")
$reportPath = "C:\Logs\RsopReport.$username.$date.html"

# Generate RSoP Report
try {
    # Ensure the module is available
    Import-Module GroupPolicy
    
    # Generate RSoP Data
    Get-GPResultantSetOfPolicy -ReportType html -User $domain\$username -Path $reportPath
    Write-Output "RSoP report is generated successfully at $reportPath."
} catch {
    Write-Error "Error generating RSoP report: $_"
}